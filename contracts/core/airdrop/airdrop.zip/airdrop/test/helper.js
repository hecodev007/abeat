const { MerkleTree } = require("merkletreejs");
const keccak256 = require("keccak256");
const Web3 = require("web3");
const web3 = new Web3();

let data = [
  {
    address: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
    amount: 10000,
    index: 0,
  },
  {
    address: "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266",
    amount: 20000,
    index: 1,
  },
];

function formatNumber(num) {
  return web3.utils.padLeft(web3.utils.numberToHex(num).slice(2), 64);
}

data = data.map((it) => ({
  data: it.address + formatNumber(it.amount) + formatNumber(it.index),
  ...it,
}));

const leaves = data.map((v) => keccak256(v.data));
const tree = new MerkleTree(leaves, keccak256, { sort: true });
const root = tree.getHexRoot();

exports.getRoot = function () {
  return root;
};

exports.getProof = function (index) {
  const proof = tree.getHexProof(keccak256(data[index].data));
  return { proof, ...data[index] };
};
