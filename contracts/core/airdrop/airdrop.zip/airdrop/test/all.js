const { expect } = require("chai");
const { ethers } = require("hardhat");
const { getRoot, getProof } = require("./helper");
describe("Test Contract start", function () {
  it("start dispatcher--->", async function () {
    const [owner] = await ethers.getSigners();
    const USDT = await ethers.getContractFactory("MONA");
    const usdtContract = await USDT.deploy(owner.address);
    await usdtContract.deployed();
    const usdtAddress = usdtContract.address;
    const root = getRoot();
    const Dispatcher = await ethers.getContractFactory("Dispatcher");
    const dispatcherContract = await Dispatcher.deploy(root, usdtAddress);
    await dispatcherContract.deployed();
    await usdtContract.approve(
      dispatcherContract.address,
      "100000000000000000000000000000000000000"
    );
    await dispatcherContract.deposit(30000);
    const proofData = getProof(0);
    await expect(
      dispatcherContract.claim(1, proofData.amount, proofData.proof)
    ).to.be.revertedWith("C:1");
    const claimBeforeBalance = await usdtContract.balanceOf(owner.address);
    await dispatcherContract.claim(0, proofData.amount, proofData.proof);
    const claimAfterBalance = await usdtContract.balanceOf(owner.address);
    expect(claimBeforeBalance.add("10000").toString()).to.eq(
      claimAfterBalance.toString()
    );
  });  
});
